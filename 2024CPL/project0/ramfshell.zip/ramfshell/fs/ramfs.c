#include "../include/ramfs.h"
#include <assert.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

node *root = NULL;

#define NRFD 4096
FD fdesc[NRFD];

char *strdup(const char *s) {
    if (s == NULL) {
        return NULL;
    }

    size_t len = strlen(s) + 1;//\0
    char *p = (char *)malloc(len);
    if (p != NULL) {
        strcpy(p, s);
    }

    return p;
}

node *find(const char *pathname) {
    if (pathname[0]!='/') {
        return NULL;
    }
    node *cur = root;
    char *path = strdup(pathname);
    char *token = strtok(path, "/");
    //绝对路径从大到小一一对应
    while (token != NULL) {
      bool found = false;
      for (int i = 0; i < cur->nrde; i++) {
        if (strcmp(token, cur->dirents[i]->name) == 0) {
            cur = cur->dirents[i];
            found = true;
            break;
        }
      }
      if (!found) {
        free(path);
        return NULL;
      }
      token = strtok(NULL, "/");
    }
    free(path);
    return cur;
}

//是否存在 是否可以新建
int ropen(const char *pathname, int flags) {
    node *file = find(pathname);

    //文件不存在且可以创建
    if (!file && (flags & O_CREAT)) {
      char *path = strdup(pathname);
      char *next_path = strrchr(path, '/');
      //有父目录且状态正常
      if (!next_path) {
        free(path);
        return -1;
      }
      *next_path = '\0';
      node *parent = find(next_path);
      if (!parent||parent->type != DNODE) {
        free(path);
        return -1;
      }
      node *new_file = malloc(sizeof(node));
      //分开的父目录和文件名，中间隔开的下一个
      new_file->name = strdup(next_path+1);
      new_file->type = DNODE;
//      new_file->content = NULL;
      new_file->size = 0;
      parent->dirents[parent->nrde++] = new_file;
      free(path);
      return 0;
    }
    if (file) {
      if(flags & O_APPEND) {
        file->content += file->size;
      }
      if(flags & O_TRUNC) {
        free(file->content);
        file->content = NULL;
        file->size = 0;
      }
      return 0;
    }
    return -1;
}

int rclose(int fd) {

}

ssize_t rwrite(int fd, const void *buf, size_t count) {

}

ssize_t rread(int fd, void *buf, size_t count) {

}

off_t rseek(int fd, off_t offset, int whence) {

}

int rmkdir(const char *pathname) {

}

int rrmdir(const char *pathname) {

}

int runlink(const char *pathname) {

}

void init_ramfs() {
    root = malloc(sizeof(node));
    root->type = DNODE;
    root->name = "/";
    root->dirents = malloc(sizeof(node*) * NRFD);
    root->nrde = 0;
    root->size = 0;
    root->content=NULL;
}

void close_ramfs() {
    free(root->dirents);
    free(root);
}