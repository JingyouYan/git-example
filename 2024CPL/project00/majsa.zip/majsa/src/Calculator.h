#pragma once
#include "main.h"

int calHan(Status *status);  // 计算番数

int calFu(Status *status);  // 计算符数

int calPoint(Status *status);  // 计算点数

int calMachi(Status *status);  // 计算面听数